/**
 * GET /
 * Profile page.
 */
exports.getProfile = (req, res) => {
      res.render('profile', {
        title: 'Profile'
      });
};
