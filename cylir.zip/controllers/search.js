/**
 * GET /
 * Search page.
 */
exports.getSearch = (req, res) => {
      res.render('search', {
        title: 'Search'
      });
};
